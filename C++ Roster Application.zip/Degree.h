//C867 Scripting and Programming	
//Roster PA
//Jayson Valderrama
//Student ID 001081738 


#pragma once

enum Degree{
	SECURITY, NETWORKING, SOFTWARE
};
